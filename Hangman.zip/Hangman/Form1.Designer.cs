﻿namespace Hangman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonNewGame = new System.Windows.Forms.Button();
            this.buttonQuit = new System.Windows.Forms.Button();
            this.pictureBoxHangMan = new System.Windows.Forms.PictureBox();
            this.buttonReset = new System.Windows.Forms.Button();
            this.AButton = new System.Windows.Forms.Button();
            this.WButton = new System.Windows.Forms.Button();
            this.QButton = new System.Windows.Forms.Button();
            this.EButton = new System.Windows.Forms.Button();
            this.RButton = new System.Windows.Forms.Button();
            this.TButton = new System.Windows.Forms.Button();
            this.YButton = new System.Windows.Forms.Button();
            this.UButton = new System.Windows.Forms.Button();
            this.IButton = new System.Windows.Forms.Button();
            this.OButton = new System.Windows.Forms.Button();
            this.PButton = new System.Windows.Forms.Button();
            this.SButton = new System.Windows.Forms.Button();
            this.DButton = new System.Windows.Forms.Button();
            this.FButton = new System.Windows.Forms.Button();
            this.GButton = new System.Windows.Forms.Button();
            this.HButton = new System.Windows.Forms.Button();
            this.JButton = new System.Windows.Forms.Button();
            this.KButton = new System.Windows.Forms.Button();
            this.ZButton = new System.Windows.Forms.Button();
            this.XButton = new System.Windows.Forms.Button();
            this.MButton = new System.Windows.Forms.Button();
            this.NButton = new System.Windows.Forms.Button();
            this.BButton = new System.Windows.Forms.Button();
            this.CButton = new System.Windows.Forms.Button();
            this.VButton = new System.Windows.Forms.Button();
            this.SpaceButton = new System.Windows.Forms.Button();
            this.LButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHangMan)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonNewGame
            // 
            this.buttonNewGame.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonNewGame.AutoEllipsis = true;
            this.buttonNewGame.Location = new System.Drawing.Point(29, 22);
            this.buttonNewGame.Name = "buttonNewGame";
            this.buttonNewGame.Size = new System.Drawing.Size(175, 49);
            this.buttonNewGame.TabIndex = 0;
            this.buttonNewGame.Text = "New Game";
            this.buttonNewGame.UseVisualStyleBackColor = true;
            this.buttonNewGame.Click += new System.EventHandler(this.buttonNewGame_Click);
            // 
            // buttonQuit
            // 
            this.buttonQuit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonQuit.Location = new System.Drawing.Point(29, 92);
            this.buttonQuit.Name = "buttonQuit";
            this.buttonQuit.Size = new System.Drawing.Size(175, 49);
            this.buttonQuit.TabIndex = 2;
            this.buttonQuit.Text = "End Game";
            this.buttonQuit.UseVisualStyleBackColor = true;
            this.buttonQuit.Click += new System.EventHandler(this.buttonQuit_Click);
            // 
            // pictureBoxHangMan
            // 
            this.pictureBoxHangMan.Location = new System.Drawing.Point(29, 166);
            this.pictureBoxHangMan.Name = "pictureBoxHangMan";
            this.pictureBoxHangMan.Size = new System.Drawing.Size(442, 911);
            this.pictureBoxHangMan.TabIndex = 4;
            this.pictureBoxHangMan.TabStop = false;
            // 
            // buttonReset
            // 
            this.buttonReset.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonReset.AutoEllipsis = true;
            this.buttonReset.Location = new System.Drawing.Point(223, 22);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(175, 49);
            this.buttonReset.TabIndex = 5;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // AButton
            // 
            this.AButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AButton.AutoEllipsis = true;
            this.AButton.Location = new System.Drawing.Point(529, 520);
            this.AButton.Name = "AButton";
            this.AButton.Size = new System.Drawing.Size(49, 49);
            this.AButton.TabIndex = 6;
            this.AButton.Text = "A";
            this.AButton.UseVisualStyleBackColor = true;
            this.AButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // WButton
            // 
            this.WButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.WButton.AutoEllipsis = true;
            this.WButton.Location = new System.Drawing.Point(558, 465);
            this.WButton.Name = "WButton";
            this.WButton.Size = new System.Drawing.Size(49, 49);
            this.WButton.TabIndex = 7;
            this.WButton.Text = "W";
            this.WButton.UseVisualStyleBackColor = true;
            this.WButton.Click += new System.EventHandler(this.WButton_Click);
            // 
            // QButton
            // 
            this.QButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.QButton.AutoEllipsis = true;
            this.QButton.Location = new System.Drawing.Point(503, 465);
            this.QButton.Name = "QButton";
            this.QButton.Size = new System.Drawing.Size(49, 49);
            this.QButton.TabIndex = 8;
            this.QButton.Text = "Q";
            this.QButton.UseVisualStyleBackColor = true;
            this.QButton.Click += new System.EventHandler(this.QButton_Click);
            // 
            // EButton
            // 
            this.EButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EButton.AutoEllipsis = true;
            this.EButton.Location = new System.Drawing.Point(613, 465);
            this.EButton.Name = "EButton";
            this.EButton.Size = new System.Drawing.Size(49, 49);
            this.EButton.TabIndex = 9;
            this.EButton.Text = "E";
            this.EButton.UseVisualStyleBackColor = true;
            this.EButton.Click += new System.EventHandler(this.EButton_Click);
            // 
            // RButton
            // 
            this.RButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.RButton.AutoEllipsis = true;
            this.RButton.Location = new System.Drawing.Point(668, 465);
            this.RButton.Name = "RButton";
            this.RButton.Size = new System.Drawing.Size(49, 49);
            this.RButton.TabIndex = 10;
            this.RButton.Text = "R";
            this.RButton.UseVisualStyleBackColor = true;
            this.RButton.Click += new System.EventHandler(this.RButton_Click);
            // 
            // TButton
            // 
            this.TButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TButton.AutoEllipsis = true;
            this.TButton.Location = new System.Drawing.Point(723, 465);
            this.TButton.Name = "TButton";
            this.TButton.Size = new System.Drawing.Size(49, 49);
            this.TButton.TabIndex = 11;
            this.TButton.Text = "T";
            this.TButton.UseVisualStyleBackColor = true;
            this.TButton.Click += new System.EventHandler(this.TButton_Click);
            // 
            // YButton
            // 
            this.YButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.YButton.AutoEllipsis = true;
            this.YButton.Location = new System.Drawing.Point(778, 465);
            this.YButton.Name = "YButton";
            this.YButton.Size = new System.Drawing.Size(49, 49);
            this.YButton.TabIndex = 12;
            this.YButton.Text = "Y";
            this.YButton.UseVisualStyleBackColor = true;
            this.YButton.Click += new System.EventHandler(this.YButton_Click);
            // 
            // UButton
            // 
            this.UButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.UButton.AutoEllipsis = true;
            this.UButton.Location = new System.Drawing.Point(833, 465);
            this.UButton.Name = "UButton";
            this.UButton.Size = new System.Drawing.Size(49, 49);
            this.UButton.TabIndex = 13;
            this.UButton.Text = "U";
            this.UButton.UseVisualStyleBackColor = true;
            this.UButton.Click += new System.EventHandler(this.UButton_Click);
            // 
            // IButton
            // 
            this.IButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IButton.AutoEllipsis = true;
            this.IButton.Location = new System.Drawing.Point(888, 465);
            this.IButton.Name = "IButton";
            this.IButton.Size = new System.Drawing.Size(49, 49);
            this.IButton.TabIndex = 14;
            this.IButton.Text = "I";
            this.IButton.UseVisualStyleBackColor = true;
            this.IButton.Click += new System.EventHandler(this.IButton_Click);
            // 
            // OButton
            // 
            this.OButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OButton.AutoEllipsis = true;
            this.OButton.Location = new System.Drawing.Point(943, 465);
            this.OButton.Name = "OButton";
            this.OButton.Size = new System.Drawing.Size(49, 49);
            this.OButton.TabIndex = 15;
            this.OButton.Text = "O";
            this.OButton.UseVisualStyleBackColor = true;
            this.OButton.Click += new System.EventHandler(this.OButton_Click);
            // 
            // PButton
            // 
            this.PButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PButton.AutoEllipsis = true;
            this.PButton.Location = new System.Drawing.Point(998, 465);
            this.PButton.Name = "PButton";
            this.PButton.Size = new System.Drawing.Size(49, 49);
            this.PButton.TabIndex = 16;
            this.PButton.Text = "P";
            this.PButton.UseVisualStyleBackColor = true;
            this.PButton.Click += new System.EventHandler(this.PButton_Click);
            // 
            // SButton
            // 
            this.SButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SButton.AutoEllipsis = true;
            this.SButton.Location = new System.Drawing.Point(584, 520);
            this.SButton.Name = "SButton";
            this.SButton.Size = new System.Drawing.Size(49, 49);
            this.SButton.TabIndex = 18;
            this.SButton.Text = "S";
            this.SButton.UseVisualStyleBackColor = true;
            this.SButton.Click += new System.EventHandler(this.SButton_Click);
            // 
            // DButton
            // 
            this.DButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DButton.AutoEllipsis = true;
            this.DButton.Location = new System.Drawing.Point(639, 520);
            this.DButton.Name = "DButton";
            this.DButton.Size = new System.Drawing.Size(49, 49);
            this.DButton.TabIndex = 20;
            this.DButton.Text = "D";
            this.DButton.UseVisualStyleBackColor = true;
            this.DButton.Click += new System.EventHandler(this.DButton_Click);
            // 
            // FButton
            // 
            this.FButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FButton.AutoEllipsis = true;
            this.FButton.Location = new System.Drawing.Point(694, 520);
            this.FButton.Name = "FButton";
            this.FButton.Size = new System.Drawing.Size(49, 49);
            this.FButton.TabIndex = 21;
            this.FButton.Text = "F";
            this.FButton.UseVisualStyleBackColor = true;
            this.FButton.Click += new System.EventHandler(this.FButton_Click);
            // 
            // GButton
            // 
            this.GButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GButton.AutoEllipsis = true;
            this.GButton.Location = new System.Drawing.Point(749, 520);
            this.GButton.Name = "GButton";
            this.GButton.Size = new System.Drawing.Size(49, 49);
            this.GButton.TabIndex = 22;
            this.GButton.Text = "G";
            this.GButton.UseVisualStyleBackColor = true;
            this.GButton.Click += new System.EventHandler(this.GButton_Click);
            // 
            // HButton
            // 
            this.HButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.HButton.AutoEllipsis = true;
            this.HButton.Location = new System.Drawing.Point(804, 520);
            this.HButton.Name = "HButton";
            this.HButton.Size = new System.Drawing.Size(49, 49);
            this.HButton.TabIndex = 23;
            this.HButton.Text = "H";
            this.HButton.UseVisualStyleBackColor = true;
            this.HButton.Click += new System.EventHandler(this.HButton_Click);
            // 
            // JButton
            // 
            this.JButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.JButton.AutoEllipsis = true;
            this.JButton.Location = new System.Drawing.Point(859, 520);
            this.JButton.Name = "JButton";
            this.JButton.Size = new System.Drawing.Size(49, 49);
            this.JButton.TabIndex = 24;
            this.JButton.Text = "J";
            this.JButton.UseVisualStyleBackColor = true;
            this.JButton.Click += new System.EventHandler(this.JButton_Click);
            // 
            // KButton
            // 
            this.KButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.KButton.AutoEllipsis = true;
            this.KButton.Location = new System.Drawing.Point(914, 520);
            this.KButton.Name = "KButton";
            this.KButton.Size = new System.Drawing.Size(49, 49);
            this.KButton.TabIndex = 25;
            this.KButton.Text = "K";
            this.KButton.UseVisualStyleBackColor = true;
            this.KButton.Click += new System.EventHandler(this.KButton_Click);
            // 
            // ZButton
            // 
            this.ZButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ZButton.AutoEllipsis = true;
            this.ZButton.Location = new System.Drawing.Point(584, 575);
            this.ZButton.Name = "ZButton";
            this.ZButton.Size = new System.Drawing.Size(49, 49);
            this.ZButton.TabIndex = 26;
            this.ZButton.Text = "Z";
            this.ZButton.UseVisualStyleBackColor = true;
            this.ZButton.Click += new System.EventHandler(this.ZButton_Click);
            // 
            // XButton
            // 
            this.XButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.XButton.AutoEllipsis = true;
            this.XButton.Location = new System.Drawing.Point(639, 575);
            this.XButton.Name = "XButton";
            this.XButton.Size = new System.Drawing.Size(49, 49);
            this.XButton.TabIndex = 27;
            this.XButton.Text = "X";
            this.XButton.UseVisualStyleBackColor = true;
            this.XButton.Click += new System.EventHandler(this.XButton_Click);
            // 
            // MButton
            // 
            this.MButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MButton.AutoEllipsis = true;
            this.MButton.Location = new System.Drawing.Point(914, 575);
            this.MButton.Name = "MButton";
            this.MButton.Size = new System.Drawing.Size(49, 49);
            this.MButton.TabIndex = 28;
            this.MButton.Text = "M";
            this.MButton.UseVisualStyleBackColor = true;
            this.MButton.Click += new System.EventHandler(this.MButton_Click);
            // 
            // NButton
            // 
            this.NButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NButton.AutoEllipsis = true;
            this.NButton.Location = new System.Drawing.Point(859, 575);
            this.NButton.Name = "NButton";
            this.NButton.Size = new System.Drawing.Size(49, 49);
            this.NButton.TabIndex = 29;
            this.NButton.Text = "N";
            this.NButton.UseVisualStyleBackColor = true;
            this.NButton.Click += new System.EventHandler(this.NButton_Click);
            // 
            // BButton
            // 
            this.BButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BButton.AutoEllipsis = true;
            this.BButton.Location = new System.Drawing.Point(804, 575);
            this.BButton.Name = "BButton";
            this.BButton.Size = new System.Drawing.Size(49, 49);
            this.BButton.TabIndex = 30;
            this.BButton.Text = "B";
            this.BButton.UseVisualStyleBackColor = true;
            this.BButton.Click += new System.EventHandler(this.BButton_Click);
            // 
            // CButton
            // 
            this.CButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CButton.AutoEllipsis = true;
            this.CButton.Location = new System.Drawing.Point(694, 575);
            this.CButton.Name = "CButton";
            this.CButton.Size = new System.Drawing.Size(49, 49);
            this.CButton.TabIndex = 31;
            this.CButton.Text = "C";
            this.CButton.UseVisualStyleBackColor = true;
            this.CButton.Click += new System.EventHandler(this.CButton_Click);
            // 
            // VButton
            // 
            this.VButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.VButton.AutoEllipsis = true;
            this.VButton.Location = new System.Drawing.Point(749, 575);
            this.VButton.Name = "VButton";
            this.VButton.Size = new System.Drawing.Size(49, 49);
            this.VButton.TabIndex = 32;
            this.VButton.Text = "V";
            this.VButton.UseVisualStyleBackColor = true;
            this.VButton.Click += new System.EventHandler(this.VButton_Click);
            // 
            // SpaceButton
            // 
            this.SpaceButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SpaceButton.AutoEllipsis = true;
            this.SpaceButton.Location = new System.Drawing.Point(668, 630);
            this.SpaceButton.Name = "SpaceButton";
            this.SpaceButton.Size = new System.Drawing.Size(214, 49);
            this.SpaceButton.TabIndex = 33;
            this.SpaceButton.Text = "Space";
            this.SpaceButton.UseVisualStyleBackColor = true;
            this.SpaceButton.Click += new System.EventHandler(this.SpaceButton_Click);
            // 
            // LButton
            // 
            this.LButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LButton.AutoEllipsis = true;
            this.LButton.Location = new System.Drawing.Point(969, 520);
            this.LButton.Name = "LButton";
            this.LButton.Size = new System.Drawing.Size(49, 49);
            this.LButton.TabIndex = 34;
            this.LButton.Text = "L";
            this.LButton.UseVisualStyleBackColor = true;
            this.LButton.Click += new System.EventHandler(this.LButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2212, 1189);
            this.Controls.Add(this.LButton);
            this.Controls.Add(this.SpaceButton);
            this.Controls.Add(this.VButton);
            this.Controls.Add(this.CButton);
            this.Controls.Add(this.BButton);
            this.Controls.Add(this.NButton);
            this.Controls.Add(this.MButton);
            this.Controls.Add(this.XButton);
            this.Controls.Add(this.ZButton);
            this.Controls.Add(this.KButton);
            this.Controls.Add(this.JButton);
            this.Controls.Add(this.HButton);
            this.Controls.Add(this.GButton);
            this.Controls.Add(this.FButton);
            this.Controls.Add(this.DButton);
            this.Controls.Add(this.SButton);
            this.Controls.Add(this.PButton);
            this.Controls.Add(this.OButton);
            this.Controls.Add(this.IButton);
            this.Controls.Add(this.UButton);
            this.Controls.Add(this.YButton);
            this.Controls.Add(this.TButton);
            this.Controls.Add(this.RButton);
            this.Controls.Add(this.EButton);
            this.Controls.Add(this.QButton);
            this.Controls.Add(this.WButton);
            this.Controls.Add(this.AButton);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.pictureBoxHangMan);
            this.Controls.Add(this.buttonQuit);
            this.Controls.Add(this.buttonNewGame);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHangMan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonNewGame;
        private System.Windows.Forms.Button buttonQuit;
        private System.Windows.Forms.PictureBox pictureBoxHangMan;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button AButton;
        private System.Windows.Forms.Button WButton;
        private System.Windows.Forms.Button QButton;
        private System.Windows.Forms.Button EButton;
        private System.Windows.Forms.Button RButton;
        private System.Windows.Forms.Button TButton;
        private System.Windows.Forms.Button YButton;
        private System.Windows.Forms.Button UButton;
        private System.Windows.Forms.Button IButton;
        private System.Windows.Forms.Button OButton;
        private System.Windows.Forms.Button PButton;
        private System.Windows.Forms.Button SButton;
        private System.Windows.Forms.Button DButton;
        private System.Windows.Forms.Button FButton;
        private System.Windows.Forms.Button GButton;
        private System.Windows.Forms.Button HButton;
        private System.Windows.Forms.Button JButton;
        private System.Windows.Forms.Button KButton;
        private System.Windows.Forms.Button ZButton;
        private System.Windows.Forms.Button XButton;
        private System.Windows.Forms.Button MButton;
        private System.Windows.Forms.Button NButton;
        private System.Windows.Forms.Button BButton;
        private System.Windows.Forms.Button CButton;
        private System.Windows.Forms.Button VButton;
        private System.Windows.Forms.Button SpaceButton;
        private System.Windows.Forms.Button LButton;
    }
}

