﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangman
{
    class WordHolder
    {
        public int Start { get; set; }
        public int End { get; set; }

        private List<WordHolder> _slotCollection = null;
        public List<WordHolder> SlotCollection { get { return _slotCollection; } }

        public WordHolder() { }

        public WordHolder(int count)
        {
            WordHolder obj = null;
            _slotCollection = new List<WordHolder>();

            if (count < 1000)
            {
                SlotCollection.Add(new WordHolder() { Start = 0, End = count });
                return;
            }
            else
            {
                int endValue = 0;

                for (int i = 0; i < count; i += 1000)
                {
                    obj = new WordHolder()
                    {
                        Start = i == 0 ? i : i + 1,
                        End = count - endValue > 1000 ? (1000 + endValue) : i + (count - endValue)
                    };

                    _slotCollection.Add(obj);
                    endValue += 1000;
                }
            }
        }
    }
}
